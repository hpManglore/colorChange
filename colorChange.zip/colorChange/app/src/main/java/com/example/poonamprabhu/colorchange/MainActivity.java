package com.example.poonamprabhu.colorchange;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    EditText text;
    Button button1,button2,button3,button4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.color);

        text=findViewById(R.id.t1);
        button1=findViewById(R.id.b1);
        button2=findViewById(R.id.b2);
        button3=findViewById(R.id.b3);
        button4=findViewById(R.id.b4);

        text.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {


            }

            @Override
            public void afterTextChanged(Editable s) {
               if(text.getText().toString().equals("RED") || text.getText().toString().equals("red"))
               {
                   button1.setBackgroundColor(Color.RED);
                   button2.setBackgroundColor(Color.GRAY);
                   button3.setBackgroundColor(Color.GRAY);
                   button4.setBackgroundColor(Color.GRAY);
               }
               else
               if(text.getText().toString().equals("BLACK") || text.getText().toString().equals("black"))
               {
                   button2.setBackgroundColor(Color.BLACK);
                   button1.setBackgroundColor(Color.GRAY);
                   button3.setBackgroundColor(Color.GRAY);
                   button4.setBackgroundColor(Color.GRAY);
               }
               else
               if(text.getText().toString().equals("BLUE") || text.getText().toString().equals("blue"))
               {
                   button3.setBackgroundColor(Color.BLUE);
                   button2.setBackgroundColor(Color.GRAY);
                   button1.setBackgroundColor(Color.GRAY);
                   button4.setBackgroundColor(Color.GRAY);
               }
                   else
               if(text.getText().toString().equals("GREEN") || text.getText().toString().equals("green"))
               {
                   button4.setBackgroundColor(Color.GREEN);
                   button2.setBackgroundColor(Color.GRAY);
                   button3.setBackgroundColor(Color.GRAY);
                   button1.setBackgroundColor(Color.GRAY);
               }
               else
               if(text.getText().toString().equals("CLEAR") || text.getText().toString().equals("clear")|| text.getText().toString().equals(""))
               {
                  button1.setBackgroundColor(Color.GRAY);
                   button2.setBackgroundColor(Color.GRAY);
                   button3.setBackgroundColor(Color.GRAY);
                   button4.setBackgroundColor(Color.GRAY);
               }
               else
                   {
                        button1.setBackgroundColor(Color.GRAY);
                   button2.setBackgroundColor(Color.GRAY);
                   button3.setBackgroundColor(Color.GRAY);
                   button4.setBackgroundColor(Color.GRAY);
                   }


                String n=text.getText().toString();
               String str[];

               str=n.split(",");
               for(int i=0;i<str.length;i++)
               {
                   if(str[i].equals("red"))
                       button1.setBackgroundColor(Color.RED);
                   if(str[i].equals("black"))
                       button2.setBackgroundColor(Color.BLACK);
                   if(str[i].equals("blue"))
                       button3.setBackgroundColor(Color.BLUE);
                   if(str[i].equals("green"))
                       button4.setBackgroundColor(Color.GREEN);

               }

            }
        });



    }
}
